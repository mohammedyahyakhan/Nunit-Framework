﻿using System;
using System.Threading;
using System.Collections.ObjectModel;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Support.UI;
using AppiumAndroid;
using OpenQA.Selenium.Appium;

namespace AppiumAndroid
{
    [TestFixture("single", "pixel")]
    public class LocalTest : BrowserStackNUnitTest
    {
        public LocalTest(string profile, string device) : base(profile,device){ }
        [Test]
        [Obsolete]
        public void searchWikipedia()
        {
            AndroidElement searchElement = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(ExpectedConditions.ElementToBeClickable(MobileBy.AccessibilityId("Search Wikipedia")));
            searchElement.Click();
            AndroidElement insertTextElement = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(ExpectedConditions.ElementToBeClickable(By.Id("org.wikipedia.alpha:id/search_src_text")));
            insertTextElement.SendKeys("BrowserStack");
            Thread.Sleep(5000);

            ReadOnlyCollection<AndroidElement> allProductsName = driver.FindElements(By.ClassName("android.widget.TextView"));
            Assert.True(allProductsName.Count > 0);
        }
        [Test]
        [Obsolete]
        public void testLocal()
        {
           // AndroidElement AllowButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.widget.Button[@text='ALLOW']")));
           // AllowButton.Click();

           // int counter = 0;
           // while (AllowButton.Displayed)
           // {
           //     AllowButton.Click();

           //     if (counter == 4)
           //     {
           //         break;
           //     }
           //     counter++;
           // }

           // AndroidElement OkButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //     ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.widget.Button[@text='OK']")));
           // OkButton.Click();

           // AndroidElement UsernameInputBox = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //     ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.view.View[1]/android.view.View[1]/android.widget.EditText")));
           // UsernameInputBox.SendKeys("Test");

           // AndroidElement PasswordInputBox = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //     ExpectedConditions.ElementToBeClickable(MobileBy.Id("loginPassword")));
           // PasswordInputBox.SendKeys("Testtest");

           // AndroidElement SignInButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //     ExpectedConditions.ElementToBeClickable(MobileBy.XPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[4]/android.widget.Button")));
           // SignInButton.Click();
        }
        [Test]
        [Obsolete]
        public void testLocal1()
        {
           // AndroidElement AllowButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.widget.Button[@text='ALLOW']")));
           // AllowButton.Click();

           // int counter = 0;
           // while (AllowButton.Displayed)
           // {
           //     AllowButton.Click();

           //     if (counter == 4)
           //     {
           //         break;
           //     }
           //     counter++;
           // }

           // AndroidElement OkButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //     ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.widget.Button[@text='OK']")));
           // OkButton.Click();

           // AndroidElement UsernameInputBox = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //     ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.view.View[1]/android.view.View[1]/android.widget.EditText")));
           // UsernameInputBox.SendKeys("Test");

           // AndroidElement PasswordInputBox = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //     ExpectedConditions.ElementToBeClickable(MobileBy.Id("loginPassword")));
           // PasswordInputBox.SendKeys("Testtest");

           // AndroidElement SignInButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
           //     ExpectedConditions.ElementToBeClickable(MobileBy.XPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[4]/android.widget.Button")));
           // SignInButton.Click();
        }
        
    }
}
