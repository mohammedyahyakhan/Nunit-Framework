﻿using System;
using System.Threading;
using System.Collections.ObjectModel;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Support.UI;

namespace AppiumAndroid
{
    [TestFixture("single", "pixel")]
    public class SingleTest : BrowserStackNUnitTest
  {
    public SingleTest(string profile, string device) : base(profile,device){}

    [Test]
    [Obsolete]
        public void searchWikipedia()
    {
            AndroidElement AllowButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
            ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.widget.Button[@text='ALLOW']")));
            AllowButton.Click();

            int counter = 0;
            while (AllowButton.Displayed)
            {
                AllowButton.Click();
                
                if (counter == 4)
                {
                    break;
                }
                counter++;
            }

            AndroidElement OkButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
                ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.widget.Button[@text='OK']")));
            OkButton.Click();

            AndroidElement UsernameInputBox = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
                ExpectedConditions.ElementToBeClickable(MobileBy.XPath("//android.view.View[1]/android.view.View[1]/android.widget.EditText")));
            UsernameInputBox.SendKeys("Test");

            AndroidElement PasswordInputBox = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
                ExpectedConditions.ElementToBeClickable(MobileBy.Id("loginPassword")));
            PasswordInputBox.SendKeys("Testtest");

            AndroidElement SignInButton = (AndroidElement)new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(
                ExpectedConditions.ElementToBeClickable(MobileBy.XPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[4]/android.widget.Button")));
            SignInButton.Click();
        }
  }
}
